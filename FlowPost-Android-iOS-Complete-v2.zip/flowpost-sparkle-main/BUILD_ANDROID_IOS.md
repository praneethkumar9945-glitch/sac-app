# FlowPost / SAC Community — Build Android & iOS

App: SAC Community · App ID: `app.saccommunity.mobile`
Web: https://flow-post-sparkle.lovable.app (hosted — the apps load this site, they are not offline)
Status on 2026-11-23: complete project, verified here — `bun run test` 10/10 pass, `bun run build` passes, `bun run mobile:sync` passes.
**No APK / IPA is included in this zip.** The debug APK could not be built in this Linux workspace (Gradle daemon would not run here — see MOBILE.md). Build it on your own machine with the steps below; it takes about 10 minutes in Android Studio.

## Android — install on your phone (debug APK)

1. Install Android Studio (includes SDK 36 + JDK 21) and Node.js 22+.
2. Unzip this project, open a terminal in it:
   ```
   bun install
   bun run mobile:sync
   ```
   (If you don't have bun: `npm install` then `npx cap sync`.)
3. Open Android Studio → Open → select the `android/` folder. Let Gradle sync finish.
4. Plug in your Android phone (USB debugging on) or start an emulator, then press Run.
   Or for an APK file: Build → Build App Bundle(s) / APK(s) → Build APK(s).
   Or from terminal: `cd android && ./gradlew assembleDebug`
   APK: `android/app/build/outputs/apk/debug/app-debug.apk`
   Copy it to your phone and tap it to install. It needs internet — the app loads the hosted site.

## Android — Play Store (release)

In Android Studio: Build → Generate Signed App Bundle → Android App Bundle.
Create your own private keystore when asked and keep it + its passwords OUTSIDE this project.
Upload the `.aab` in Google Play Console. You need a Google Play developer account.

## iOS — iPhone / TestFlight (needs a Mac)

1. On a Mac with Xcode 26+ and Node.js 22+:
   ```
   bun install
   bun run mobile:sync
   bun run mobile:ios
   ```
2. In Xcode, select the App target → Signing & Capabilities → set your Apple Developer Team.
   Bundle ID must stay `app.saccommunity.mobile`.
3. Run on a simulator or your iPhone.
4. For TestFlight: Product → Archive → Distribute App. Needs an Apple Developer account ($99/yr) + App Store Connect.

## What's inside

- Home, Reels, Explore, Messages, Notifications, Create, Profile, Saved, Bookings
- Settings (Instagram-style): Insights (followers / views / interactions), Account privacy, Report a problem, Blocked, Close connections, Recent activity, Favorites, Device permissions, Help, Privacy settings, Accounts & passwords, Privacy policy, Terms of use, Account verification, Log out
- Android permissions: Camera, Microphone, Photos/Videos, Notifications. Deep link: `https://flow-post-sparkle.lovable.app` + `saccommunity://`
- iOS permissions: Camera, Microphone, Photo Library (same descriptions in Info.plist)

## Before publishing to a store

Test on a real phone: sign-in, email verification links, camera/gallery, video upload, keyboard, notch/status bar, Android back button, offline → reconnect.
A hosted-site wrapper can be rejected by Apple for minimum functionality — add a privacy policy URL, data-safety disclosures, reporting/blocking, and account deletion before submitting. See MOBILE.md.

## No Android Studio? Build the APK on GitHub (free, no install)

1. Create a free GitHub account if you don't have one, and create a new empty repository.
2. Upload this whole project folder to that repository (GitHub web: Add file → Upload files, or `git push`).
3. On GitHub, open the **Actions** tab → **Build Android APK** → **Run workflow** → Run.
4. Wait about 5–10 minutes for the green tick, then click the finished run and download **sac-community-debug-apk** under Artifacts.
5. Unzip it, copy `app-debug.apk` to your Android phone, tap it to install.

The workflow file is `.github/workflows/build-android-apk.yml` — it installs Node, Bun, JDK 21 and the Android SDK on GitHub's machine, runs `bun install` + `bun run mobile:sync`, then builds the APK for you.
