import type { CapacitorConfig } from '@capacitor/cli';

// Hosted SSR and account services are required; this app is not a static SPA.
const config: CapacitorConfig = {
  appId: 'app.saccommunity.mobile',
  appName: 'SAC Community',
  webDir: 'mobile-web',
  server: {
    url: 'https://flow-post-sparkle.lovable.app',
    cleartext: false,
    errorPath: 'offline.html',
  },
  android: { allowMixedContent: false },
  ios: { contentInset: 'automatic' },
  plugins: {
    SplashScreen: {
      // App dark background: --background oklch(0.13 0.004 20) in src/styles.css.
      launchShowDuration: 1500,
      backgroundColor: '#090707',
    },
    StatusBar: {
      style: 'dark',
      backgroundColor: '#090707',
    },
    Keyboard: {
      resizeMode: 'ionic',
    },
  },
};

export default config;