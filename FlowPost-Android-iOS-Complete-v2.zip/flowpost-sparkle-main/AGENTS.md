<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Expose home stories through one pointer-draggable floating button; keep the position within viewport bounds and distinguish dragging from tapping.
- Keep sample content in an explicit local fixture module, visibly labeled Demo, and never write sample interactions to real accounts.
- Render the floating story control and viewer in body portals so surrounding page elements cannot clip them.
- Keep profile people lists in ConnectionsList and connection actions in ConnectButton; shared query invalidation keeps counts and lists consistent after actions.
- Open profile people lists in a dialog from header controls rather than a section below Highlights, keeping the profile content uninterrupted.
- Keep content creation options (including New Highlight) in the shared CreateMenu, opened from the "New" circle in the own-profile Highlights row; no separate Create button.
- Keep media overlay colors independent of the page theme and use the shared social Button variant for composer actions, so controls stay legible in both appearance modes.
- Keep music selection and preview editing in the shared MusicPicker; stream catalog previews only in the editor and save title/artist through the existing content fields, because preview playback is not a published soundtrack.
- Keep account verification in AccountVerification with account-specific field definitions; never persist identity details or documents locally or claim submission before private storage and review persistence are connected.
- Keep Capacitor Android/iOS projects pointed at the explicit HTTPS published origin with a bundled connection-error page; the TanStack Start app requires hosted SSR and must not be treated as static Vite output. Keep signing secrets outside source control.
- Keep the public Supabase URL and publishable key in `src/integrations/supabase/projectConfig.ts` as fallbacks; never put service-role keys there, so browser auth works without reserved environment names.
