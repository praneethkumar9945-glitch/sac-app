# SAC Community — Android and iOS

Both native projects are generated with Capacitor 8. They load **https://flow-post-sparkle.lovable.app** with the existing design. This is an online, hosted-site wrapper, not an offline app. Publishing website changes updates what it displays; unpublished preview changes will not appear in it.

## What is included

- `android/`: Android Studio project, app ID `app.saccommunity.mobile`, Android 7+ (API 24), targeting API 36.
- `ios/`: Xcode project, same app ID, iOS 15+.
- `capacitor.config.ts`: exact HTTPS origin, no cleartext or mixed-content allowance, no wildcard navigation.
- `mobile-web/`: bundled connection-error page with retry.
- Existing posts, stories, reels, and account forms remain hosted on the website.

## Native hardening (2026-11-23)

Verified in this Linux workspace (no Mac/Xcode here, so iOS was validated by config/XML checks only, not by an Xcode build):

- **Android `AndroidManifest.xml`**: added `CAMERA`, `RECORD_AUDIO`, `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `POST_NOTIFICATIONS` (kept `INTERNET`, `usesCleartextTraffic="false"`). Added an App Link intent-filter on `MainActivity` (`android:autoVerify`, `VIEW`/`DEFAULT`/`BROWSABLE`, `https` scheme, host `flow-post-sparkle.lovable.app`); the `LAUNCHER` filter is untouched. Note: App Links only take over automatically once `https://flow-post-sparkle.lovable.app/.well-known/assetlinks.json` is published on the hosted site with this app's SHA-256 signing fingerprint — until then links may still offer a chooser.
- **iOS `Info.plist`**: kept the existing camera/mic/photo-library descriptions; added `NSPhotoLibraryAddUsageDescription` (saving media to the library) and `CFBundleURLTypes` for the `saccommunity` URL scheme (`saccommunity://` links open the app). Plist XML validated by parsing.
- **`capacitor.config.ts`**: added `plugins` config — `SplashScreen` (`launchShowDuration` 1500, `backgroundColor` `#090707`, the app dark background from `--background: oklch(0.13 0.004 20)` in `src/styles.css`), `StatusBar` (`style: dark`, same `#090707`), `Keyboard` (`resizeMode: ionic`). `server.url`, `cleartext: false`, `allowMixedContent: false`, `webDir: mobile-web`, `errorPath: offline.html` unchanged.
- **Plugins installed** (official Capacitor 8 only, no push/camera/filesystem plugins — no backend keys exist for them): `@capacitor/app@8.1.2`, `@capacitor/status-bar@8.0.4`, `@capacitor/splash-screen@8.0.2`, `@capacitor/keyboard@8.0.6`, `@capacitor/haptics@8.0.2`. `bun run mobile:sync` registers all five in both native projects. They are installed but not yet called from web code — wire them in (e.g. haptics on taps, `App.addListener('appUrlOpen')` for deep links) only when the web feature work for them is planned.
- **`mobile-web/offline.html` + `index.html`**: only a `<meta name="theme-color" content="#090707">` was added; the retry link to the hosted URL is unchanged.
- **Verified here**: `bun run mobile:sync` succeeds for android + ios; `bun run test` 10/10 pass; `bun run build` passes; both edited XML files parse; `capacitor.config.json` generated in both native projects carries the new plugin settings.

## Android installation file

**Debug APK build — attempted 2026-11-23 in this Linux workspace, NOT completed.** No APK was produced; do not treat one as existing. What was set up: OpenJDK 21 (`apt`, `openjdk-21-jdk-headless` 21.0.13.1), Android SDK installed at `~/workspace/flowpost/android-sdk/` (outside the project: cmdline-tools, platform-tools, `platforms;android-36`, `build-tools;36.0.0`, aapt2 verified working), Gradle 8.14.3 pre-seeded in `~/.gradle`, and the egress-proxy CA imported into the JDK truststore. What failed, in order: (1) `sdkmanager` cannot fetch the package list through this VM's authenticated egress proxy — `java.util.NoSuchElementException` in `HttpURLConnection.doTunneling`; worked around by downloading the platform/build-tools/platform-tools zips directly with `curl` (which honours the proxy) from `dl.google.com` using the URLs in `repository2-1.xml`. (2) The Gradle wrapper re-download attempt failed the same way (its JVM gets no proxy settings), worked around by running the pre-seeded Gradle binary directly — `--version` works. (3) Every build attempt then fails with `FAILURE: Build failed with an exception. * What went wrong: Could not receive a message from the daemon.` — the daemon JVM starts (seen briefly alive) but the client never receives from it, and no daemon log is ever written; tried with the daemon, with a reused live daemon, and with `--no-daemon` (single-use fork) — same error each time. Likely cause: this sandbox kills/restricts the daemon process or its local socket, compounded by only ~350–400 MB free RAM against a 1 GB Gradle heap. Per the task's retry limit this was not retried further. **To build the APK, run it on a normal machine (or Android Studio):** `bun install`, `bun run mobile:sync`, then in `android/` run `./gradlew assembleDebug` with `ANDROID_HOME` pointing at a full SDK 36 install and JDK 21. The APK will be at `android/app/build/outputs/apk/debug/app-debug.apk`.

1. Install Node.js 22+, Android Studio with SDK 36, and its compatible JDK (21).
2. Run `bun install` (or install dependencies using npm), then `bun run mobile:sync`.
3. Run `bun run mobile:android` to open Android Studio.
4. Let Gradle sync, select a device/emulator, and run the app.
5. For a test APK: use Build → Generate App Bundles or APKs → Generate APKs, or run `./gradlew assembleDebug` inside `android/`.
6. For Play Store: Generate Signed App Bundle, create/store a private signing key outside this repository, and upload the AAB using your Google Play developer account. A release AAB needs a private keystore the user creates — never commit a keystore or its passwords to the repo.

## iPhone installation / TestFlight

1. Use a Mac with Xcode 26+ and Node.js 22+.
2. Install dependencies, run `bun run mobile:sync`, then `bun run mobile:ios`.
3. In Xcode select the App target, set your Apple Developer Team under Signing & Capabilities, and confirm your bundle identifier is available.
4. Run on an iPhone simulator/device. For TestFlight select a device archive destination, then Product → Archive → Distribute App.
5. Store distribution requires an Apple Developer account and App Store Connect setup.

## Before release

- Native APK/IPA compilation was **attempted but not completed in this Linux workspace** (see the debug-APK note above: the Gradle daemon cannot run here). No APK/IPA exists yet. A Mac with Xcode 26+ is still required for any iOS build, plus an Apple Developer account ($99/yr) and App Store Connect setup for TestFlight/store distribution; signing/provisioning must be configured in Xcode under Signing & Capabilities with the bundle ID `app.saccommunity.mobile`.
- Test email sign-in, verification links, session restoration, camera/gallery selection, video/audio uploads, keyboard, notch/status bar, Android back, and reconnection on real Android/iOS devices. A desktop browser does not validate native behavior.
- Email verification delivery and verification-form submission limitations in the existing website are not repaired by packaging.
- Google/Apple OAuth and email links returning to the app need an explicit native callback/deep-link flow; do not assume embedded browser login is sufficient.
- Add native features as needed for store acceptance. A hosted website wrapper alone may be rejected, especially under Apple's minimum-functionality rules; store approval is not guaranteed.
- Supply privacy policy, support URL, data safety/privacy disclosures, moderation/reporting/blocking for social content, account deletion, screenshots and age rating. Audit these against current store requirements.
- Keep signing keys, service secrets, provisioning profiles and `local.properties` out of any source delivery.

## Development

`bun run mobile:sync` copies the connection page and config to both native projects. It deliberately does not build the SSR website as static files. Deploy website updates separately using the existing Lovable workflow.